package loginsteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSteps {
	public ChromeDriver driver;
	@Given("Open the chrome browser")
	public void openBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	@Given("Load the application url as {string}")
	public void loadApplicationUrl(String url) {
		driver.get(url);
	}
	@Given("Enter the username as {string}")
	public void enter_the_username_as_demosalesmanger(String username) {
		driver.findElement(By.id("email")).sendKeys(username);	
	}
	@Given("Enter the password as {string}")
	public void enter_the_password_as_crmsfa(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
	}
	@When("Click on Login button")
	public void click_on_login_button() {
		driver.findElement(By.id("login-submit")).click();
	}
	@Then("Homepage should be displayed")
	public void verify_Homepage() {
		if(driver.getTitle().contains("eShipz")) {
			System.out.println("My HomePage is displayed..");
		}else {
		     System.out.println("HomePage is not displayed..");	
			}
	}
	@When("Click Create Shipment")
	public void click_createShipment() {
		WebElement createShipment = driver.findElement(By.xpath("(//a[contains(text(),'Create Shipment')])"));
		Actions builder = new Actions(driver);
		builder.moveToElement(createShipment).perform();
	}
	@When("Click Reverse")
	public void click_reverse() {
		driver.findElement(By.xpath("//a[@title='Quick Shipment Creation - Reverse']")).click();
	}
	@Then("Logout the page")
	public void logout_thePage() {
		driver.findElement(By.xpath("//i[text()='exit_to_app']")).click();
	}
	
	

}
