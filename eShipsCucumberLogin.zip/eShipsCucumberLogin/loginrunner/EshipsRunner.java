package loginrunner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
		features = "src/main/java/features/Login.feature",
		glue = "loginsteps",//steps package name
		monochrome = true,//to avoid junk characters
		publish = true)//to get a cucumber report in the console
public class EshipsRunner extends AbstractTestNGCucumberTests{
	
}
